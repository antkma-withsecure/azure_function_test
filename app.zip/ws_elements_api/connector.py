from datetime import datetime, timezone, timedelta
from time import sleep
from json import *
from base64 import *

from utils import build_signature

import requests


WS_ID = "<change me>"  # replace with `Workspace ID from Log Analytics
WS_KEY = "<change me>"  # replace with `Primary Key`
LOG_TYPE = "MY_TEST_SECURITY_EVENTS"
LOG_SERVICE = "https://" + WS_ID + ".ods.opinsights.azure.com"

API_URL = "https://api.connect-ci.fsapi.com"
CLIENT_ID = "<change_me>"  # Elements API client id
CLIENT_SECRET = "<change_me>"  # Elements API client secret
EVENTS_PATH = "/security-events/v1/security-events"


def send_to_azure(body):  # body must be in text format
    method = "POST"
    content_type = "application/json"
    resource = "/api/logs"
    rfc1123date = datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
    content_length = len(body)
    signature = build_signature(
        WS_ID, WS_KEY, rfc1123date, content_length, method, content_type, resource
    )
    uri = LOG_SERVICE + resource + "?api-version=2016-04-01"

    headers = {
        "content-type": content_type,
        "Authorization": signature,
        "Log-Type": LOG_TYPE,
        "x-ms-date": rfc1123date,
    }
    print("Sending to Azure: headers=", headers)
    response = requests.post(uri, data=body, headers=headers)
    if response.status_code >= 200 and response.status_code <= 299:
        return response.status_code
    else:
        print(
            "Events are not processed into Azure. Response code",
            response.status_code,
            "error=",
            response.text,
        )
        return None


# Reads single page of events, that were created after given
# timestamp.
def get_events_page(auth_token, min_date, org_id=None, next_page=None):
    headers = {
        "Accept": "application/json",  # always use that header if you expect JSON response
        "Authorization": "Bearer " + auth_token,
        "User-Agent": "my-script",
    }

    params = {
        "limit": 20,
        "persistenceTimestampStart": min_date,  # read all events created AFTER `min_date`
        "order": "asc",  # ascending order
    }

    params["exclusiveStart"] = "true"

    if next_page:
        params["anchor"] = next_page

    if org_id:
        params["organizationId"] = org_id
    #    print(params)
    response = requests.get(API_URL + EVENTS_PATH, params=params, headers=headers)

    if not response.ok:
        print("Error", response.text)
        raise Exception("Request error")

    return response.json()


def azure_format(event):
    return {
        "organization_id": event["organization"]["id"],
        "target_id": event["device"]["id"],
        "severity": event["severity"],
        "event_id": event["id"],
        "persistence_ts": event["persistenceTimestamp"],
        "engine": event["engine"],
    }


# Get all events persisted after `min_dt`. Function reads all pages
# that are produced by request.
def get_events_after(auth_token, min_dt, org_id):
    # Elements API accepts timestamps in [RFC 3339](https://datatracker.ietf.org/doc/html/rfc3339#section-5.6)
    # format: YYYY-MM-DDThh:mm:ss.fff
    last_date = min_dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    next_page = None
    fetch_page = True
    print("Reading events created after {}".format(last_date))
    all_events = []
    while fetch_page:
        page = get_events_page(auth_token, last_date, org_id, next_page)
        next_page = page.get("nextAnchor")

        # If `nextAnchor` is present we should fetch next page in next iteration
        fetch_page = next_page is not None
        for event in page["items"]:
            print(
                "EventId={}, EventTs={}".format(
                    event["id"], event["persistenceTimestamp"]
                )
            )
            all_events.append(azure_format(event))
            last_date = event["persistenceTimestamp"]

    return (datetime.strptime(last_date, "%Y-%m-%dT%H:%M:%S.%fZ"), all_events)


def poll_security_events(
    client_id, client_secret, poll_interval, org_id=None, start_delta=timedelta()
):
    # initialize start date with current timestamp
    last_date = datetime.now(timezone.utc) - start_delta
    print("Start polling", last_date)

    # start infinite loop
    while True:
        # obtain authentication token
        auth_token = authenticate(client_id, client_secret)
        last_date, all_events = get_events_after(auth_token, last_date, org_id)
        print("Last date", last_date, len(all_events))
        status = send_to_azure(dumps(all_events))
        print("Azure=", status)
        # execute next iteration every `poll_interval`
        sleep(poll_interval)


def authenticate(client_id, client_secret):
    auth_header = b64encode(bytes(client_id + ":" + client_secret, "utf-8")).decode(
        "utf-8"
    )
    headers = {
        "Content-type": "application/x-www-form-urlencoded;charset=UTF-8",
        "Accept": "application/json",
        "Authorization": "Basic " + auth_header,
        "User-Agent": "my-script",  # each request must contain User-Agent header
    }
    scopes = [
        "connect.api.read",
        #   "connect.api.write"
    ]  # authenticated client can read
    # and write data

    data = {"grant_type": "client_credentials", "scope": " ".join(scopes)}

    response = requests.post(API_URL + "/as/token.oauth2", data=data, headers=headers)
    if response.ok:
        res_body = response.json()
        return res_body["access_token"]
    else:
        print("Response=" + response.text)
        print("Headers=" + str(response.headers))

        print("Transaction-id=" + response.headers.get("X-Transaction"))
        raise Exception("Authentication failed")


if __name__ == "__main__":
    org_id = None
    sd = timedelta(minutes=15)
    poll_security_events(CLIENT_ID, CLIENT_SECRET, 60, org_id, sd)
