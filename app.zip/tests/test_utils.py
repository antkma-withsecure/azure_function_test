from datetime import datetime

from ws_elements_api.utils import build_signature


def test_build_signature():
    date = datetime.fromisoformat("2011-11-04T00:05:23").strftime(
        "%a, %d %b %Y %H:%M:%S GMT"
    )
    content = "test content"
    shared_key = "GgfrNWyDAmUoGxWReRDciz4glqWoH7ELoRy7cobvqBMbAC9JeBdSAbkSvmaWRdf9MU2JE33J8l5jc1ulsqrr+A=="
    sig = build_signature(
        "test_workspace_id",
        shared_key,
        date,
        len(content),
        "POST",
        "application/json",
        "/api/logs",
    )

    assert (
        sig
        == "SharedKey test_workspace_id:BxQZJ18OfmJ1XGBnQ6xGGcQSar17A6isZtf76sWfAtE="
    )
