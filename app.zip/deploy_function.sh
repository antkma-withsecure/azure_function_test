#!/bin/sh

# this file contains secrets and is not published to source control
deployment_name=${1?"Please provide deployment name"}
resource_group=${2?"Please provide resource group"}
parameters_file_path=${3?"Please provide json parameters file path"}

template_file="azuredeploy_function_app.json"

if (( ! $(az group exists --name $resource_group) ))
then
  echo "Resource group $resource_group doesn't exist. Creating..."
  az group create --location westeurope --name "$resource_group" || exit
fi

echo "Deploying infrastructure resources from template $template_file..."
result=$(az deployment group create --name "$deployment_name" --resource-group "$resource_group" --template-file $template_file --parameters "@$parameters_file_path" || exit)

echo "Waiting until infrastructure is created..."
# az deployment group wait --name antkma_withsecure_connector_azure_function --resource-group $resource_group --created
sleep 10

echo "Publishing function to function app $function_app..."
function_app=$(echo "${result}" | jq .properties.outputs.functionAppName.value | tr -d '"')
zip -r app.zip . --exclude @.funcignore --exclude .funcignore
az functionapp deployment source config-zip --resource-group "$resource_group" --name "$function_app" --src app.zip --build-remote true