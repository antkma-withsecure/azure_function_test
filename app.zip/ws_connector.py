import logging


class Connector:
    def __init__(self, withsecure_client, sentinel_client, storage_client):
        self._withsecure_client = withsecure_client
        self._sentinel_client = sentinel_client
        self._storage_client = storage_client

    def execute(self):
        # TODO: haven't tested any resilience solutions - so not sure what will happen when network connection fails
        last_timestamp = self._storage_client.get_start_timestamp()

        logging.info("Start polling from %s", last_timestamp)
        all_events = self._withsecure_client.get_events_after(last_timestamp)
        if len(all_events) == 0:
            logging.info('No new events found')
            return
        logging.info(f'Found {len(all_events)} since {last_timestamp}')
        new_last_timestamp = all_events[-1]['persistenceTimestamp']
        logging.info(f'Last persistenceTimestamp: {new_last_timestamp}')

        # TODO: in case when function was down for too long it might timeout without moving forward
        # it will get the same old timestamp every execution
        # maybe limit of that can be greater if execution happens every 5 minutes instead of every minute
        status = self._sentinel_client.upload_events(
            list(map(lambda event: self.to_sentinel_format(event), all_events)))
        logging.info("Azure= %s", status)

        # TODO: if sentinel receives events and saving new timestamp fails there is no mechanism to prevent duplicates
        if 200 <= status <= 299:
            self._storage_client.save_start_timestamp(new_last_timestamp)
            logging.info(f'Updated timestamp in storage to: {new_last_timestamp}')
        else:
            logging.info(f'Timestamp in storage has not been updated')

    @staticmethod
    def to_sentinel_format(event):
        result = {
            "severity": event["severity"],
            "event_id": event["id"],
            "persistence_ts": event["persistenceTimestamp"],
            "engine": event["engine"]
        }

        organization = event["organization"]
        target = event["target"]

        if organization is not None:
            result["organization_id"] = organization["id"]
        if target is not None:
            result["target_id"] = target["id"]

        return result
