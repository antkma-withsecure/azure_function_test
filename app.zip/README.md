# Sentinel Connector with Azure Function

For the steps to deploy connector to Azure check [Deploy](#deploy) section.

If you want to experiment with the function code locally check [Run](#Run) section.

## Run

Simplest way to test and run function locally is to use VS Code with following extensions:

* [Python](https://marketplace.visualstudio.com/items?itemName=ms-python.python)
* [Azure Functions](https://marketplace.visualstudio.com/items?itemName=ms-azuretools.vscode-azurefunctions)
* [Azurite V3](https://marketplace.visualstudio.com/items?itemName=Azurite.azurite)

Start with verifying installation of Azure Functions Core Tools. In VS Code press `F1` then start command:

    Azure Functions: Install or Update Core Tools

Then next step is to start Azure emulator. In VS Code press `F1` and run command

    Azurite: Start

Running services should appear on the bottom status bar in VS Code.

To start function in emulator it needs to be appended to Azure Functions. To do so go to **Run and Debug** and select
**Attach to Python Functions** or simply use shortcut `F5` in VS Code. Function should automatically start locally.

To learn more visit:
[Quickstart: Create a function in Azure with Python using VS Code](https://learn.microsoft.com/en-us/azure/azure-functions/create-first-function-vs-code-python?pivots=python-mode-decorators)

TODO: how to run function against local storage account?

## Deploy

### Required tools
 - [Azure CLI](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli)

### Steps

[//]: # (TODO: describe parameters)
1. Clone this repo
2. Log in to Azure Portal via Azure CLI 
   ```shell
   az login
   ```
3. Create resource group
   ```shell
   az group create --name "$resource_group" --location "$location"
   ```
   where `$resource_group` is a placeholder for the resource group name, `$location` is a placeholder for the resource group location.
4. **[ Optional ]** Deploy Key Vault.  You can use your custom Key Vault, just ensure that required secrets are there (`ws-client-id`, `ws-client-secret`). In this directory:
   1. Create `azuredeploy.keyvault.parameters.json` file with the format shown in [this section](#azuredeploykeyvaultparametersjson-file-format). Fill in missing values.
   2. Invoke:
   ```shell
   az deployment group create --name "$deployment_name" --resource-group "$resource_group" --template-file azuredeploy_key_vault.json --parameters @azuredeploy.keyvault.parameters.json
   ```
   `$deployment-name` is a placeholder for the deployment name, `$resource-group` is a placeholder for the resource group name.
   
   Script will create Key Vault with configured secrets `ws-client-id` and `ws-client-secret`. By default, Key Vault name is `"$resource_group"-vault`. Name can be customized by providing "keyVaultName" in `azuredeploy.function.parameters.json`.
5. Deploy function app with related resources. In this directory:
   1. Create `azuredeploy.function.parameters.json` file with the format shown in [this section](#azuredeployfunctionparametersjson-file-format). Fill in missing values.
   2. Invoke:  
   ```shell
   az deployment group create --name "$deployment_name" --resource-group "$resource_group" --template-file azuredeploy_function_app.json --parameters @azuredeploy.function.parameters.json
   ```
   `$deployment-name` is a placeholder for the deployment name, `$resource-group` is a placeholder for the resource group name.

   If you want to deploy multiple function apps under the same resource group use different `deployment-name` each time. Otherwise, resources are updated and no new resource is created.
   
   Following resources will be created:
   - storage account (provide `storageAccountName` parameter in parameters file; `"$resource_group"` by default)
   - table under created storage account (provide `storageAccountTableName` parameter in parameters file; `"$resource_group"-storage` by default)
   - function app with all required configuration and with monitoring enabled (provide `functionAppName` parameter in parameters file; `"$resource_group"-app` by default)
6. Deploy function to the Function App. From the `data_connector` folder invoke:

   [//]: # (TODO: is pip install needed?)
   ```shell
   pip install -r requirements.txt
   ```
7. Create zip file of the `data_connector` folder with the utility of your choice 
8. Invoke:
   ```shell
   az functionapp deployment source config-zip --resource-group "$resource_group" --name "$function_app" --src "$app.zip" --build-remote false
   ```
   where `$resource_group` is a placeholder for your resource group name, `$function_app` is a placeholder for the function app name to which you want to publish the connector function 
   and `$app.zip` is path to the created zip file.
   
   Function `upload_security_events` will be created under the function app.

### Deploy function to the function app
This readme file describes three ways to deploy connector function to the function app:
- [Using Azure CLI](#using-azure-cli)

#### Using Azure CLI
From the `data_connector` folder invoke:

[//]: # (TODO: is pip install needed?)
```shell
pip install -r requirements.txt
```
then create zip file of the `data_connector` folder with the utility of your choice and invoke:
```shell
az functionapp deployment source config-zip --resource-group "$resource_group" --name "$function_app" --src "$app.zip" --build-remote false
```
where `$resource_group` is a placeholder for your resource group name, `$function_app` is a placeholder for the function app name to which you want to publish the connector function 
and `$app.zip` is path to the created zip file.

### azuredeploy.keyvault.parameters.json file format
 ```json
      {
          "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
          "contentVersion": "1.0.0.0",
          "parameters": {
              "wsClientId": {
                  "value": "..."
              },
              "wsClientSecret": {
                  "value": "..."
              }
          }
      }
 ```
`wsClientId` and `wsClientSecret` are the values from the Elements Portal. Select **API clients** tab under **Management** section.
### azuredeploy.function.parameters.json file format
```json
   {
      "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
      "contentVersion": "1.0.0.0",
      "parameters": {
         "workspaceId": {
            "value": "..."
         },
         "workspaceKey": {
            "value": "..."
         },
         "keyVaultName": {
            "value": "..."
         }
      }
  }
```
`workspaceId` and `workspaceKey` - can be found in **Log Analytics workspace**. Under **Settings** select **Agents**. 
Click **Log Analytics agent instructions** to display. Workspace ID is a value for `workspaceId` and
Primary key is a value for `workspaceKey`. `keyVaultName` - use name of the Key Vault that contains `ws-client-id` and `ws-client-secret`.

### Monitoring

To monitor deployed function simply log in to Azure and go to **Function App** and select your function.
On the list you should be able to see Monitor options for deployed function as well as it's type and status.
Click **Invocations and more** select **Logs** to see logs in real time. You can see some graphed metrics in 
the **Overview**.