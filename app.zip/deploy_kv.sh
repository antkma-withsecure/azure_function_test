#!/bin/sh

# this file contains secrets and is not published to source control
deployment_name=${1?"Please provide deployment name"}
resource_group=${2?"Please provide resource group"}
parameters_file_path=${3?"Please provide json parameters file path"}

template_file="azuredeploy_key_vault.json"

if (( ! $(az group exists --name $resource_group) ))
then
  echo "Resource group $resource_group doesn't exist. Creating..."
  az group create --location westeurope --name "$resource_group" || exit
fi

echo "Deploying infrastructure resources from template $template_file..."
az deployment group create --name "$deployment_name" --resource-group "$resource_group" --template-file $template_file --parameters "@$parameters_file_path"