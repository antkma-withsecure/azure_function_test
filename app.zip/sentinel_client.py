import json
import logging
from datetime import datetime, timezone

from requests import post

from utils import build_signature


class SentinelClient:
    def __init__(self, workspace_id, primary_key):
        self._WORKSPACE_ID = workspace_id
        self._WORKSPACE_KEY = primary_key
        self._LOG_TYPE = "WITHSECURE_SECURITY_EVENTS"
        self._LOG_SERVICE = f'https://{self._WORKSPACE_ID}.ods.opinsights.azure.com'

    def upload_events(self, events):
        body = json.dumps(events)
        method = "POST"
        content_type = "application/json"
        resource = "/api/logs"
        rfc1123date = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT")
        content_length = len(body)
        signature = build_signature(
            self._WORKSPACE_ID, self._WORKSPACE_KEY, rfc1123date, content_length, method, content_type, resource
        )
        uri = self._LOG_SERVICE + resource + "?api-version=2016-04-01"

        headers = {
            "content-type": content_type,
            "Authorization": signature,
            "Log-Type": self._LOG_TYPE,
            "x-ms-date": rfc1123date,
        }
        logging.info("Sending to Azure: headers=", headers)
        response = post(uri, data=body, headers=headers)
        if 200 <= response.status_code <= 299:
            return response.status_code
        else:
            logging.info(
                "Events are not processed into Azure. Response code",
                response.status_code,
                "error=",
                response.text,
            )
            return None
