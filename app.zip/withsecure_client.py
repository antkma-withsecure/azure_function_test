import logging
from base64 import b64encode

from requests import post


class WithSecureClient:
    def __init__(self, client_id, client_secret):
        self._CLIENT_ID = client_id
        self._CLIENT_SECRET = client_secret
        self._API_URL = "https://api.connect-ci.fsapi.com"
        self._EVENTS_PATH = "/security-events/v1/security-events"

    def get_events_after(self, from_date):
        token = self._authenticate()
        return self._get_events_after(token, from_date)

    def _authenticate(self):
        auth_header = b64encode(bytes(self._CLIENT_ID + ":" + self._CLIENT_SECRET, "utf-8")).decode(
            "utf-8"
        )
        headers = {
            "Content-type": "application/x-www-form-urlencoded;charset=UTF-8",
            "Accept": "application/json",
            "Authorization": "Basic " + auth_header,
            "User-Agent": "sentinel-connector",
        }

        data = {"grant_type": "client_credentials", "scope": "connect.api.read"}

        response = post(self._API_URL + "/as/token.oauth2", data=data, headers=headers)
        if response.ok:
            res_body = response.json()
            return res_body["access_token"]
        else:
            logging.info("Response=" + response.text)
            logging.info("Headers=" + str(response.headers))

            logging.info("Transaction-id=" + response.headers.get("X-Transaction"))
            raise Exception("Authentication failed")

    def _get_events_after(self, auth_token, from_date, org_id=None):
        next_page = None
        fetch_page = True
        logging.info("Reading events created after {}".format(from_date))
        all_events = []
        while fetch_page:
            page = self._get_events_page(auth_token, from_date, org_id, next_page)
            next_page = page.get("nextAnchor")

            fetch_page = next_page is not None
            for event in page["items"]:
                all_events.append(event)

        return all_events

    def _get_events_page(self, auth_token, from_date, org_id=None, next_page=None):
        headers = {
            "Accept": "application/json",
            "Authorization": "Bearer " + auth_token,
            "User-Agent": "my-script",
        }

        data = {"limit": 20,
                "persistenceTimestampStart": from_date,
                "order": "asc", "engineGroup": "epp,edr", "exclusiveStart": "true"}

        if next_page:
            data["anchor"] = next_page

        if org_id:
            data["organizationId"] = org_id

        response = post(self._API_URL + self._EVENTS_PATH, data=data, headers=headers)

        if not response.ok:
            logging.info("Error %s", response.text)
            raise Exception("Request error")

        return response.json()
