from azure.core.exceptions import ResourceNotFoundError
from azure.keyvault.secrets import SecretClient, KeyVaultSecret
from azure.identity import DefaultAzureCredential
import logging


class AzureKeyVault:
    def __init__(self, key_vault_name):
        key_vault_url = f"https://{key_vault_name}.vault.azure.net/"
        credential = DefaultAzureCredential()
        self.secret_client = SecretClient(vault_url=key_vault_url, credential=credential)

    def get_secret(self, key) -> KeyVaultSecret:
        try:
            secret = self.secret_client.get_secret(key)
            return secret
        except ResourceNotFoundError:
            logging.info("No value in the vault for the key: %s" % str(key))
            return None
        except Exception as e:
            logging.error("Exception getting value from Azure Key Vault %s" % str(e))
            raise
