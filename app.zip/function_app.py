import logging

import azure.functions as func
import os

from azure_storage_table import StorageTableClient
from sentinel_client import SentinelClient
from withsecure_client import WithSecureClient
from ws_connector import Connector
from azure_key_vault import AzureKeyVault

app = func.FunctionApp()

CLIENT_ID = "ws_client_id"
CLIENT_SECRET = "ws_client_secret"

KEY_VAULT_NAME = "key_vault_name"
CLIENT_ID_KEY_VAULT = "ws-client-id"
CLIENT_SECRET_KEY_VAULT = "ws-client-secret"

WS_ID = "workspace_id"
WS_KEY = "workspace_key"

CONNECTION_STRING = "connection_string"
TABLE_NAME = "table_name"


@app.schedule(schedule="0 * * * * *", arg_name="timer", run_on_startup=True,
              use_monitor=False)
def upload_security_events(timer: func.TimerRequest) -> None:
    if timer.past_due:
        logging.info('The timer is past due!')

    workspace_id = os.environ.get(WS_ID)
    workspace_key = os.environ.get(WS_KEY)
    connection_string = os.environ.get(CONNECTION_STRING)
    table_name = os.environ.get(TABLE_NAME)
    key_vault_name = os.environ.get(KEY_VAULT_NAME)
    logging.info("Key vault {}".format(key_vault_name))
    if key_vault_name is None:
        client_id = os.environ.get(CLIENT_ID)
        client_secret = os.environ.get(CLIENT_SECRET)
    else:
        logging.info("Reading from Key Vault {}".format(key_vault_name))
        key_vault = AzureKeyVault(key_vault_name)
        client_id = key_vault.get_secret(CLIENT_ID_KEY_VAULT).value
        client_secret = key_vault.get_secret(CLIENT_SECRET_KEY_VAULT).value

    if None in (workspace_id, workspace_key, connection_string, table_name, client_id, client_secret):
        raise Exception('Function app is missing required configuration.')

    storage_client = StorageTableClient(connection_string, table_name)
    sentinel_client = SentinelClient(workspace_id, workspace_key)
    withsecure_client = WithSecureClient(client_id, client_secret)

    connector = Connector(storage_client=storage_client,
                          sentinel_client=sentinel_client,
                          withsecure_client=withsecure_client)

    connector.execute()
